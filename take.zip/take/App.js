import * as React from 'react';
import {
  Text,
  View,
  StyleSheet,
  Button,
  TextInput,
  TouchableOpacity,
} from 'react-native';
import Constants from 'expo-constants';
//import { createStackNavigator, createAppContainer } from 'react-navigation';
import * as SQLite from 'expo-sqlite';

const db = SQLite.openDatabase('db.db');

class Splitit extends React.Component {
  state = {
    Amount: null,
    Name: null,
  };
  handleAmount = (text) => {
    this.setState({ Amount: text });
  };

  handleName = (text) => {
    this.setState({ Name: text });
  };

  componentDidMount() {
    db.transaction((tx) => {
      tx.executeSql(
        'create table if not exists Calculations (id integer primary key AUTOINCREMENT, Name varchar(20), Amount float(10,4), Owes_To_User integer(5));'
      );
    });

    db.transaction((tx) => {
      tx.executeSql(
        'create table if not exists Members (id integer primary key AUTOINCREMENT, Name varchar(20));'
      );
    });
    console.log('Tables created!');
  }
  //Comman function can be used to execute any query and get the query results
  ExecuteQuery = (sql, params = []) => new Promise((resolve, reject) => {
    db.transaction((trans) => {
      trans.executeSql(sql, params, (trans, results) => {
        resolve(results);
      },
        (error) => {
          reject(error);
        });
        console.log("In ExecuteQuery");
    });
  });
//insert function which will add the transactions in the Calculations table
  async insertData(amount, name){
    alert('Amount: ' + amount + ' Name:' + name);
    let selectQuery = await this.ExecuteQuery('select * from Members where Name != ?',[name]);
    var rows = selectQuery.rows;
    for (let i = 0; i < rows.length; i++) {
        var item = rows.item(i);
        console.log("ID: ",item.id," Name: ",item.Name);
        await this.ExecuteQuery('insert into Calculations(Name, Amount,Owes_To_User) values ( ?, ?, ?) ',[item.Name,(amount/4),name]); 
    }

  }/*
  insertData(amount, name) {
    //insert
    // let no_of_users;
    alert('Amount: ' + amount + ' Name:' + name);
    db.transaction((tx, results) => {
        tx.executeSql('select * from Members where Name != ?', [name], (_, { rows }) =>
            console.log(rows.length)
        );
        // (tx, results) => {
        //   console("Members selected");
          console.log(results);
        // }
        //console.log("NOU: " + no_of_users);
        tx.executeSql('insert into Calculations (Name, Amount) values (?, ?)', [
          name,
          amount,
        ]);
        tx.executeSql('select * from Calculations', [], (_, { rows }) =>
          console.log(rows)
        );
    });
    console.log('Insert successful!');
  }*/
  display(flag) {
    //display the data in Logs
    console.log(flag);
    if (flag === 1) {
      console.log("Inside 1");
      db.transaction((tx) => {
        tx.executeSql('select * from Calculations', [], (_, { rows }) =>
          console.log(rows)
        );
      });
    } else if (flag === 2) {
      console.log("Inside 2");
      db.transaction((tx) => {
        tx.executeSql('select * from Members', [], (_, { rows }) =>
          console.log(rows)
        );
      });
    }
    alert('Data Displayed in logs');
    console.log('Display successful!');
  }
  addMember(name) {
    //Add memeber in Members Table
    alert('Name: ' + name);
    db.transaction((tx) => {
      tx.executeSql('insert into Members (Name) values (?)', [name]);
    });
    console.log('addMember successful!');
  }

  render() {
    return (
      <View style={styles.container}>
        <View style={styles.header}>
          <Text style={styles.headerText}>SPLIT IT</Text>
        </View>
        <TextInput
          style={styles.input}
          onChangeText={this.handleAmount}
          placeholder="Enter Amount here"
          numeric
          keyboardType={'numeric'}
        />
        <TextInput
          style={styles.input}
          onChangeText={this.handleName}
          placeholder="Enter Name"
        />
        <TouchableOpacity
          style={styles.submitButton}
          onPress={() => this.insertData(this.state.Amount, this.state.Name)}>
          <Text style={styles.submitButtonText}> Add Amount </Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={styles.submitButton}
          onPress={() => this.display(1)}>
          <Text style={styles.submitButtonText}> Display Data </Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={styles.submitButton}
          onPress={() => this.addMember(this.state.Name)}>
          <Text style={styles.submitButtonText}> Add New Member </Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={styles.submitButton}
          onPress={() => this.display(2)}>
          <Text style={styles.submitButtonText}> Display Members </Text>
        </TouchableOpacity>
      </View>
    );
  }
}
const styles = StyleSheet.create({
  container: {
    padding: 50,
  },
  header: {
    height: '15%',
    width: '100%',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },
  headerText: {
    fontSize: 20,
    color: '#33',
    letterspacing: '2',
    fontweight: 'bold',
  },
  input: {
    margin: 10,
    height: 40,
    borderColor: '#7a42f4',
    borderWidth: 2,
    autoFocus: 'true',
    textAlign: 'center',
  },
  submitButton: {
    backgroundColor: '#7a42f4',
    padding: 10,
    margin: 15,
    height: 40,
  },
  submitButtonText: {
    color: 'white',
  },
});

export default Splitit;
